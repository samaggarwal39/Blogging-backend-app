package com.blog.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogRestApisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogRestApisApplication.class, args);
	}

}
