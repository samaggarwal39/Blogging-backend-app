package com.blog.restapi.repositories;

import com.blog.restapi.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<User,Integer>{



}

